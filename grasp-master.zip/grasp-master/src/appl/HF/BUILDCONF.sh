EXE=hf
FILES="HF.f90"
generate-makefile > ${MAKEFILE}
generate-cmakelists > ${CMAKELISTSTXT}
