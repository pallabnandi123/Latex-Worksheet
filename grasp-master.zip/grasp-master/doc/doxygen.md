Documenting with Doxygen
========================

Additional manual pages should go under `doc/`.
